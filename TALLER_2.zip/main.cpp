#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int main() {
    string filename = " "; 
    string subcadena = " "; 
    cout<<"Digite el nombre del archivo .txt\n";
    cin>>filename;
    cout<<"Digite la subcadena a buscar\n";
    cin>>subcadena;

    ifstream archivo(filename);
    if (!archivo.is_open()) {
        cout << "No se pudo abrir el archivo." << endl;
        return 1;
    }

    vector<string> palabras;
    string palabra;
    string linea;
    int numeroLinea = 1;

    while (getline(archivo, linea)) {
        size_t pos = 0;
        while ((pos = linea.find(' ', pos)) != string::npos) {
            pos++; // Saltar el espacio
            size_t end_pos = linea.find(' ', pos);
            if (end_pos == string::npos) {
                end_pos = linea.length();
            }
            palabra = linea.substr(pos, end_pos - pos);
            if (palabra.find(subcadena) == 0) {  // Palabras que inician con la subcadena
                palabras.push_back(palabra);
                cout << "Palabra '" << palabra << "' empieza por la subcadena en la línea " << numeroLinea << endl;
            } else if (palabra.find(subcadena) != string::npos) {  // Palabras que contienen la subcadena
                palabras.push_back(palabra);
                cout << "Palabra '" << palabra << "' encontrada en la línea " << numeroLinea << endl;
            }
            pos = end_pos;
        }
        numeroLinea++;
    }

    archivo.close();
    return 0;
}